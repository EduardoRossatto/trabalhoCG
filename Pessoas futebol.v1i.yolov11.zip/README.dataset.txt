# Pessoas futebol > 2024-11-17 7:09pm
https://universe.roboflow.com/futebol-wg8ki/pessoas-futebol

Provided by a Roboflow user
License: CC BY 4.0

